/*: 
[Table of Contents](Table%20of%20Contents) | [Previous](@previous) | [Next](@next)
****
# Document Revision History

### March 28, 2019
Updated the playground for Swift 5.0.
### June 4, 2018
Updated the playground for Swift 4.2.
### June 5, 2017
Updated the playground for Swift 4.0.
### January 24, 2017
Updated the playground for Swift 3.1.
### October 20, 2016
Updated the playground for Swift 3.0.1.
### September 13, 2016
Updated the playground for Swift 3.\
Added [Creating a Generic Collection](Creating%20a%20Generic%20Collection).
### February 22, 2016
Removed the use of `var` from a function declaration in [Understanding Value Semantics](Understanding%20Value%20Semantics).\
Updated the format of [Table of Contents](Table%20of%20Contents).
### January 25, 2016
Updated for Swift 2.2.
### September 16, 2015
Updated for Swift 2.
### June 8, 2015
A new playground document that describes how to use the Swift standard library.
****
[Table of Contents](Table%20of%20Contents) | [Previous](@previous) | [Next](@next)
*/
